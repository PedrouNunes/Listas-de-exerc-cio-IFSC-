package exercicio01;

public interface Operacoes {
    public void depositar(double valor);
    public void sacar(double valor);
}

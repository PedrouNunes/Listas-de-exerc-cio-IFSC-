package exercicio03;

import java.awt.BorderLayout;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class TelaCadastro extends javax.swing.JPanel {
    ArrayList<Pessoa> listaCandidatos;  //Objeto para armazenar candidatos cadastrados.
    
    public TelaCadastro() {
        initComponents();
        
        this.listaCandidatos = new ArrayList<>();  //Inicializa a lista.
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        tf_nome = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        tf_formacao = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        ta_areaDeInteresse = new javax.swing.JTextArea();
        bt_salvar = new javax.swing.JButton();
        bt_cancelar = new javax.swing.JButton();
        bt_proximo = new javax.swing.JButton();

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Tela de Cadastro dos Candidatos");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Nome:");

        tf_nome.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Formação:");

        tf_formacao.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("Área de Interesse:");

        ta_areaDeInteresse.setColumns(20);
        ta_areaDeInteresse.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        ta_areaDeInteresse.setRows(5);
        jScrollPane1.setViewportView(ta_areaDeInteresse);

        bt_salvar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        bt_salvar.setText("Salvar");
        bt_salvar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bt_salvarMouseClicked(evt);
            }
        });

        bt_cancelar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        bt_cancelar.setText("Cancelar");
        bt_cancelar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bt_cancelarMouseClicked(evt);
            }
        });

        bt_proximo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        bt_proximo.setText("Próximo >>");
        bt_proximo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bt_proximoMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 385, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tf_nome)
                .addGap(25, 25, 25))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tf_formacao)
                .addGap(25, 25, 25))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(bt_salvar)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(bt_cancelar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bt_proximo)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(tf_nome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(tf_formacao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bt_salvar)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bt_cancelar)
                    .addComponent(bt_proximo))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    //Clique no botão salvar.
    private void bt_salvarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bt_salvarMouseClicked
        String nome = tf_nome.getText();  //Captura os valores do formulário.
        String formacao = tf_formacao.getText();
        String areaDeInteresse = ta_areaDeInteresse.getText();

        try{
        //Verifica se todos os campos estão preenchidos.
        if(!nome.equals("") && !formacao.equals("") && !areaDeInteresse.equals("")){
            Pessoa c = new Candidato(nome, formacao, areaDeInteresse);  //Cria um objeto de candidato.
            listaCandidatos.add(c);  //Adiciona o candidato na lista.
            
            //Mostra a mensagem de sucesso.
            JOptionPane.showMessageDialog(null, "Candidato cadastrado com sucesso!", "Mensagem", JOptionPane.INFORMATION_MESSAGE);
            
            this.limpaFormulario();  //Limpa os campos dos formulário.
        }
        else{
           throw new Exception(); 
        }
        }catch(Exception e){
        //Caso algum campo não tenha sido preenchido, mostra a mensagem de erro.
            JOptionPane.showMessageDialog(null, "Você deve preencher todos os campos!", "Erro!", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bt_salvarMouseClicked
    
    //Método para limpar os campos do formulário.
    private void limpaFormulario(){
        this.tf_nome.setText("");
        this.tf_formacao.setText("");
        this.ta_areaDeInteresse.setText("");
    }
    
    //Clique no botão cancelar.
    private void bt_cancelarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bt_cancelarMouseClicked
        SwingUtilities.getWindowAncestor(this).dispose(); //Fecha o frame.
    }//GEN-LAST:event_bt_cancelarMouseClicked

    //Clique no botão próximo.
    private void bt_proximoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bt_proximoMouseClicked
       try{
       if(this.listaCandidatos.size() > 0){  //Verifica se existem candidatos cadastrados.
            Janela.telaB = new TelaGerenciamento(this.listaCandidatos, null);  //Inicializa o painel da tela de gerenciamento passando a lista de candidatos cadastrados e null para a lista de contratados.   
            JFrame janela = (JFrame)SwingUtilities.getWindowAncestor(this); //Captura a referência ao frame.
            janela.getContentPane().remove(Janela.telaA); //Remove o painel de cadastro do frame.
            janela.add(Janela.telaB, BorderLayout.CENTER); //Adiciona o painel de gerenciamento ao frame.
            janela.pack();  //Redimensiona o frame.
        }
        else{ 
           throw new Exception();
        }
       }catch(Exception e){
       //Se não houver candidatos cadastrados, mostra a mensagem de erro.
            JOptionPane.showMessageDialog(null, "Não existe nenhum candidato cadastrado!", "Erro!", JOptionPane.ERROR_MESSAGE);
       }
    }//GEN-LAST:event_bt_proximoMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt_cancelar;
    private javax.swing.JButton bt_proximo;
    private javax.swing.JButton bt_salvar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea ta_areaDeInteresse;
    private javax.swing.JTextField tf_formacao;
    private javax.swing.JTextField tf_nome;
    // End of variables declaration//GEN-END:variables
}

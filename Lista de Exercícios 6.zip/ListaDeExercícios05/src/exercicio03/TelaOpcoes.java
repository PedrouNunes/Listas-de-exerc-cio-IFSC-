package exercicio03;

import java.awt.BorderLayout;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class TelaOpcoes extends javax.swing.JPanel {
    private ArrayList<Pessoa> candidatos, contratados; //Objetos para armezanar as listas de candidatos e contratados.
    private Funcionario funcionario; //Objeto para armazenar o funcionário selecionado na tela anterior.
    
    public TelaOpcoes(ArrayList<Pessoa> candidatos, ArrayList<Pessoa> contratados, Funcionario f) {
        initComponents();
        
        //Inicializa os objetos
        this.candidatos = candidatos;
        this.contratados = contratados;
        this.funcionario = f;
        
        //Inicializa os campos de textos da tela.
        this.inicializaValores();
    }

    //Método para inicializar os valores dos campos de texto da tela baseado nos valores do funcionário selecionado na tela anterior.
    private void inicializaValores(){
        this.lb_nome.setText(this.funcionario.getNome()); //Altera a label para o nome do funcionário.
        
        //Testa se os valores de salario e jornada de trabalho estão definidos, se estiverem, converte para string e altera o valor dos campos de texto.
        if(this.funcionario.getSalario() != 0.0)
            this.tf_salario.setText(String.valueOf(this.funcionario.getSalario()));
        if(this.funcionario.getJornadaDeTrabalho() != 0)
            this.tf_jornada.setText(String.valueOf(this.funcionario.getJornadaDeTrabalho()));
        
        if(this.funcionario.isAdicionalNoturno()){ //Verifica se o funcionário recebe adicional noturno.
            this.cbx_adicional.setSelected(true);  //Se sim, marca o checkbox.
        }
        
        if(this.funcionario.isHoraExtra()){  //Verifica se o funcionário faz hora extra.
            this.cbx_horaExtra.setEnabled(true);  //Se sim, habilita o checkbox.
            this.cbx_horaExtra.setSelected(true); //Marca o checkbox.
            this.tf_jornada.setEnabled(false);  //Desabilita o campo jornada de trabalho.
        }
        else{
            if(!tf_jornada.getText().equals("")){ //Se não fizer hora extra habilita o checkbox.
                this.cbx_horaExtra.setEnabled(true);
            }
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        cbx_adicional = new javax.swing.JCheckBox();
        bt_aplicar = new javax.swing.JButton();
        lb_nome = new javax.swing.JLabel();
        tf_jornada = new javax.swing.JTextField();
        tf_salario = new javax.swing.JTextField();
        bt_aumentar = new javax.swing.JButton();
        bt_reduzir = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        cbx_horaExtra = new javax.swing.JCheckBox();

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Opções do");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Salário:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("Jornada de Trabalho:");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("Adicional Noturno:");

        cbx_adicional.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        cbx_adicional.setText("Tem direito");
        cbx_adicional.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbx_adicionalItemStateChanged(evt);
            }
        });

        bt_aplicar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        bt_aplicar.setText("<< Aplicar");
        bt_aplicar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bt_aplicarMouseClicked(evt);
            }
        });

        lb_nome.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lb_nome.setText("<nome>");

        tf_jornada.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tf_jornada.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tf_jornadaKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tf_jornadaKeyTyped(evt);
            }
        });

        tf_salario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tf_salario.setEnabled(false);

        bt_aumentar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        bt_aumentar.setText("Dar Aumento");
        bt_aumentar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bt_aumentarMouseClicked(evt);
            }
        });

        bt_reduzir.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        bt_reduzir.setText("Reduzir Salário");
        bt_reduzir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bt_reduzirMouseClicked(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Hora Extra:");

        cbx_horaExtra.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        cbx_horaExtra.setText("Faz");
        cbx_horaExtra.setEnabled(false);
        cbx_horaExtra.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbx_horaExtraItemStateChanged(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lb_nome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(18, 18, 18)
                                .addComponent(cbx_adicional))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(18, 18, 18)
                                .addComponent(tf_jornada, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel7)
                                .addGap(18, 18, 18)
                                .addComponent(cbx_horaExtra)))
                        .addGap(0, 92, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(tf_salario, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(bt_aumentar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bt_reduzir)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(169, 169, 169)
                .addComponent(bt_aplicar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(lb_nome))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel3)
                        .addComponent(tf_salario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(bt_aumentar)
                        .addComponent(bt_reduzir)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(tf_jornada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(cbx_horaExtra))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(cbx_adicional))
                .addGap(18, 18, 18)
                .addComponent(bt_aplicar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    //Clique no botão aplicar.
    private void bt_aplicarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bt_aplicarMouseClicked
        double salario = 0.0;
        int jornada = 0;
        
        //Captura os valores do formulário.
        if(!tf_salario.getText().equals(""))
            salario = Double.valueOf(tf_salario.getText());
        if(!tf_jornada.getText().equals(""))
           jornada = Integer.valueOf(this.tf_jornada.getText());
        
        try{
        //Verifica se todos os campos foram preenchidos.
        if(!tf_salario.getText().equals("") && !tf_jornada.getText().equals("")){
            this.funcionario.setSalario(salario); //Seta os valores de salario e jornada de trabalho.
            this.funcionario.setJornadaDeTrabalho(jornada);
        
            for(int i=0; i<contratados.size(); i++){  //Percorre a lista de contratados buscando pelo nome selecionado.
                if(this.funcionario.getNome().equals(contratados.get(i).getNome())){  //Ao encontrar o objeto com o mesmo nome, substitui ele na lista pelo funcionario com os valores setados.
                    this.contratados.set(i, this.funcionario);
                }
            }
        
            //Volta para a tela de visualização.
            Janela.telaC = new TelaVisualizacao(this.candidatos, this.contratados); //Inicializa o painel da tela de visualização passando as listas de candidatos e contratados.
            JFrame janela = (JFrame)SwingUtilities.getWindowAncestor(this);  //Captura a referência ao frame.
            janela.getContentPane().remove(Janela.telaD); //Remove o painel de opções do frame.
            janela.add(Janela.telaC, BorderLayout.CENTER);   //Adiciona o painel de visualização ao frame.
            janela.pack(); //Redimensiona o frame.
        }
        else{ 
            throw new Exception();
        }
        }catch(Exception e){
            //Caso algum campo não tenha sido preenchido, mostra a janela de erro.
            JOptionPane.showMessageDialog(null, "Você deve preencher todos os campos!", "Erro!", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bt_aplicarMouseClicked

    //Clique no checkbox hora extra.
    private void cbx_horaExtraItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbx_horaExtraItemStateChanged
        if(this.cbx_horaExtra.isSelected()){ //Caso o checkbox seja marcado.
            if(!this.funcionario.isHoraExtra()){  //Se o funcionário não faz hora extra, passa a fazer.
                this.funcionario.fazHoraExtra();
                this.tf_jornada.setEnabled(false);  //Desabilita o campo jornada de trabalho.
            }
        }
        else{ //Caso o checkbox seja desmarcado.
            this.funcionario.fazHoraExtra();  //Remove a hora extra do funcionário.
            this.tf_jornada.setEnabled(true); //Habilita o campo jornada de trabalho.
        }
        this.tf_jornada.setText(String.valueOf(this.funcionario.getJornadaDeTrabalho())); //Atualiza o valor do campo de texto salário.
    }//GEN-LAST:event_cbx_horaExtraItemStateChanged

    //Clique no botão aumento salarial.
    private void bt_aumentarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bt_aumentarMouseClicked
        this.funcionario.aumentoSalarial();
        this.tf_salario.setText(String.valueOf(this.funcionario.getSalario()));
    }//GEN-LAST:event_bt_aumentarMouseClicked

    //Clique no botão reduzir salario.
    private void bt_reduzirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bt_reduzirMouseClicked
        if(this.funcionario.getSalario()-1000 >= 1000){  //Testa se o salário do funcionário ficará acima de 1000 após a redução salarial.
            this.funcionario.reducaoSalarial();
            this.tf_salario.setText(String.valueOf(this.funcionario.getSalario()));
        }
        else{  //Se ficar abaixo de 1000, mostra a janela de erro.
            JOptionPane.showMessageDialog(null, "Um funcionário não pode receber menos que 1000 reais!", "Erro!", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bt_reduzirMouseClicked

    //Clique no check box adicional noturno.
    private void cbx_adicionalItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbx_adicionalItemStateChanged
        if(this.cbx_adicional.isSelected()){  //Caso o checkbox seja marcado.
            if(!this.funcionario.isAdicionalNoturno()){  //Verifica se o funcionário não recebe adicional noturno.
                this.funcionario.adicionalNoturno();  //O funcionário passa a receber o adicional.
            }
        }
        else{ //Caso o checkbox seja desmarcado.
            this.funcionario.adicionalNoturno();  //Remove o adicional noturno do funcionário.
        }
         this.tf_salario.setText(String.valueOf(this.funcionario.getSalario())); //Atualiza o valor do campo de texto salário.
    }//GEN-LAST:event_cbx_adicionalItemStateChanged

    //Método chamado quando alguma tecla é pressionada no campo jornada de trabalho.
    private void tf_jornadaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tf_jornadaKeyReleased
        String texto = this.tf_jornada.getText(); //Recupera o texto do campo de texto jornada de trabalho.
        
        //Testa se o usuário apagou todo o texto.
        if(texto.equals("")){
            this.cbx_horaExtra.setSelected(false); //Desmarca o checkbox hora extra.
            this.cbx_horaExtra.setEnabled(false);  //Desabilita o checkbox hora extra.
            this.funcionario.setJornadaDeTrabalho(0); //Altera a jornada de trabalho do funcionario pra zero.
        }
        else{ //Se tiver texto no campo.
            if(Integer.valueOf(texto) <= 40){  //Se for menor que 40 horas.
                if(!this.cbx_horaExtra.isEnabled()){  //Verifica se o checkbox está desabilitado.
                    this.cbx_horaExtra.setEnabled(true); //Habilita o checkbox.
                }
            
                if(this.cbx_horaExtra.isSelected()){  //Verifica se o checkbox está marcado.
                    this.cbx_horaExtra.setSelected(false);  //Desmarca o checkbox.
                }
            
                this.funcionario.setJornadaDeTrabalho(Integer.valueOf(texto)); //Altera a jornada de trabalho do funcionario.
            }
            else{  //Se o valor digitado for superior a 40 horas.
                this.tf_jornada.setText("");  //Altera o texto do campo para vazio.
                this.funcionario.setJornadaDeTrabalho(0);  //Altera a jornada de trabalho do funcionário para zero.
                this.cbx_horaExtra.setEnabled(false);  //Desabilita o checkbox.
                JOptionPane.showMessageDialog(null, "A jornada de trabalho não deve ultrapassar 40 horas", "Erro!", JOptionPane.ERROR_MESSAGE); //Mostra a tela de erro.
            }
        }
    }//GEN-LAST:event_tf_jornadaKeyReleased

    private void tf_jornadaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tf_jornadaKeyTyped
        char c = evt.getKeyChar();
        if ( ((c < '0') || (c > '9')) && (c != KeyEvent.VK_BACK_SPACE)) {
            evt.consume();  // if it's not a number, ignore the event
        }
    }//GEN-LAST:event_tf_jornadaKeyTyped

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt_aplicar;
    private javax.swing.JButton bt_aumentar;
    private javax.swing.JButton bt_reduzir;
    private javax.swing.JCheckBox cbx_adicional;
    private javax.swing.JCheckBox cbx_horaExtra;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel lb_nome;
    private javax.swing.JTextField tf_jornada;
    private javax.swing.JTextField tf_salario;
    // End of variables declaration//GEN-END:variables
}

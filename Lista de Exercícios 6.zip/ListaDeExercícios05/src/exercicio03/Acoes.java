package exercicio03;

//Interface
public interface Acoes {
    public void reducaoSalarial();
    public void aumentoSalarial();
    public void adicionalNoturno();
    public void fazHoraExtra();
}

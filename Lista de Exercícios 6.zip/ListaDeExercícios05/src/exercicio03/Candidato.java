package exercicio03;

public class Candidato extends Pessoa{
    //Construtor.
    public Candidato(String nome, String formacao, String area) {
        super(nome, formacao, area);
    }
}

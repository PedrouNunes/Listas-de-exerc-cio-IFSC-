package exercicio03;

import java.awt.BorderLayout;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

public class TelaVisualizacao extends javax.swing.JPanel {
    ArrayList<Pessoa> candidatos, contratados; //Objetos para armazenar as listas de candidatos e contratados.
    DefaultTableModel model;  //Objeto modelo para a tabela.
    String selecionado = null; //String para armazenar o nome do funcionário selecionado.
    
    public TelaVisualizacao(ArrayList<Pessoa> candidatos, ArrayList<Pessoa> contratados) {
        initComponents();
        
        //Inicializa as listas com os valores recebidos da tela de gerenciamento.
        this.candidatos = candidatos;
        this.contratados = contratados;
        
        //Recupera o modelo de tabela definido via GUI builder.
        this.model = (DefaultTableModel) this.tb_funcionarios.getModel();
        
        //Preenche a tabela.
        inicializaTabela();
    }
    
    //Método para preencher a tabela com os conteúdos da lista de contratados.
    public void inicializaTabela(){
        for(int i=0; i<this.contratados.size(); i++){ //Percorre a lista de contratados inserindo os elementos no modelo.
           this.model.insertRow(i, new Object[] { this.contratados.get(i).getNome() });
        }
        
        //Seta o modelo utilizado pela tabela para o modelo criado.
        this.tb_funcionarios.setModel(model);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tb_funcionarios = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        lb_formacao = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        ta_interesse = new javax.swing.JTextArea();
        bt_voltar = new javax.swing.JButton();
        bt_opcoes = new javax.swing.JButton();

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("Central de Funcionários");

        tb_funcionarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null}
            },
            new String [] {
                "Nome"
            }
        ));
        tb_funcionarios.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tb_funcionariosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tb_funcionarios);

        jLabel2.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel2.setText("Formação:");

        lb_formacao.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lb_formacao.setText("<Formação>");

        jLabel3.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel3.setText("Área de Interesse:");

        ta_interesse.setColumns(20);
        ta_interesse.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        ta_interesse.setRows(5);
        jScrollPane2.setViewportView(ta_interesse);

        bt_voltar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        bt_voltar.setText("<< Voltar");
        bt_voltar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bt_voltarMouseClicked(evt);
            }
        });

        bt_opcoes.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        bt_opcoes.setText("Opções");
        bt_opcoes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bt_opcoesMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addComponent(bt_voltar)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(bt_opcoes))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(18, 18, 18)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(lb_formacao)
                                        .addComponent(jLabel2)
                                        .addComponent(jLabel3)))
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(18, 18, 18)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(lb_formacao)
                        .addGap(43, 43, 43)
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane2)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bt_voltar)
                    .addComponent(bt_opcoes))
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    //Clique no botão voltar
    private void bt_voltarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bt_voltarMouseClicked
        Janela.telaB = new TelaGerenciamento(this.candidatos, this.contratados);  //Inicializa o painel da tela de gerenciamento passando as listas de candidatos e contratados.
        JFrame janela = (JFrame)SwingUtilities.getWindowAncestor(this); //Captura a referência ao frame.
        janela.getContentPane().remove(Janela.telaC);  //Remove o painel de visualização do frame.
        janela.add(Janela.telaB, BorderLayout.CENTER); //Adiciona o painel de gerenciamento ao frame.
        janela.pack(); //Redimensiona o frame.
    }//GEN-LAST:event_bt_voltarMouseClicked

    //Gerencia o clique na tabela.
    private void tb_funcionariosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tb_funcionariosMouseClicked
        Object temp;
        int column = 0;
        int row = this.tb_funcionarios.getSelectedRow();  //Captura o índice da linha selecionada.
        temp = this.tb_funcionarios.getModel().getValueAt(row, column); //Captura o nome da tabela através da linha e da coluna selecionada.
        
        Funcionario f = null;
        
        try{
        
        if(temp != null){
            this.selecionado = temp.toString();
            for(int i=0; i<contratados.size(); i++){  //Percorre a lista de contratados buscando pelo nome selecionado.
                if(this.selecionado.equals(contratados.get(i).getNome())){  //Ao encontrar o contratado com o mesmo nome, recupera o objeto.
                    f = (Funcionario) contratados.get(i);
                }
            }

        //Altera o valor das labels para os valores do objeto contratado.
            if(f != null){
                this.lb_formacao.setText(f.getFormacao()); 
                this.ta_interesse.setText(f.getAreaDeInteresse());
            }
        }
        else{
            throw new Exception();
        }
        }catch(Exception e){
            this.lb_formacao.setText(""); 
            this.ta_interesse.setText("");
            JOptionPane.showMessageDialog(null, "Selecione um funcionário da tabela!", "Erro!", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_tb_funcionariosMouseClicked

    //Clique no botão opções
    private void bt_opcoesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bt_opcoesMouseClicked
        if(this.selecionado != null){ //Verifica se algum funcionário foi selecionado na tabela.
            Funcionario f = null;
        
            for(int i=0; i<contratados.size(); i++){  //Percorre a lista de contratados buscando pelo nome selecionado.
                if(selecionado.equals(contratados.get(i).getNome())){  //Ao encontrar o contratado com o mesmo nome, recupera o objeto.
                    f = (Funcionario) contratados.get(i);
                }
            }

            if(f != null){
                Janela.telaD = new TelaOpcoes(this.candidatos, this.contratados, f); //Inicializa o painel da tela de visualização passando as listas de candidatos, contratados e o funcionário selecionado na tabela.
                JFrame janela = (JFrame)SwingUtilities.getWindowAncestor(this);  //Captura a referência ao frame.
                janela.getContentPane().remove(Janela.telaC); //Remove o painel de visualização do frame.
                janela.add(Janela.telaD, BorderLayout.CENTER);   //Adiciona o painel de opções ao frame.
                janela.pack(); //Redimensiona o frame.
            }
        }
        else{  //Se nenhum for selecionado na tabela, mostra a janela de erro.
            JOptionPane.showMessageDialog(null, "Selecione algum funcionário da tabela antes de continuar!", "Erro!", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bt_opcoesMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt_opcoes;
    private javax.swing.JButton bt_voltar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lb_formacao;
    private javax.swing.JTextArea ta_interesse;
    private javax.swing.JTable tb_funcionarios;
    // End of variables declaration//GEN-END:variables
}

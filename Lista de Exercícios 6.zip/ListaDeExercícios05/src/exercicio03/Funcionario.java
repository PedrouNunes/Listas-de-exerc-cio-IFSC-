package exercicio03;

public class Funcionario extends Pessoa implements Acoes{
    //Atributos.
    private double salario;
    private int jornadaDeTrabalho;
    private boolean adicionalNoturno, horaExtra;

    //Construtores.
    public Funcionario(String nome, String formacao, String area) {
        super(nome, formacao, area);
    }
    
    public Funcionario(String nome, String formacao, String area, double salario, int jornadaDeTrabalho, boolean adicionalNoturno, boolean horaExtra) {
        super(nome, formacao, area);
        this.salario = salario;
        this.jornadaDeTrabalho = jornadaDeTrabalho;
        this.adicionalNoturno = adicionalNoturno;
        this.horaExtra = horaExtra;
    }
    
    //Getters e setters.
    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public int getJornadaDeTrabalho() {
        return jornadaDeTrabalho;
    }

    public void setJornadaDeTrabalho(int jornadaDeTrabalho) {
        this.jornadaDeTrabalho = jornadaDeTrabalho;
    }

    public boolean isAdicionalNoturno() {
        return adicionalNoturno;
    }

    public void setAdicionalNoturno(boolean adicionalNoturno) {
        this.adicionalNoturno = adicionalNoturno;
    }

    public boolean isHoraExtra() {
        return horaExtra;
    }

    public void setHoraExtra(boolean horaExtra) {
        this.horaExtra = horaExtra;
    }

    //Métodos da interface.
    @Override
    public void reducaoSalarial() {
        this.salario = this.salario-1000;
    }

    @Override
    public void aumentoSalarial() {
        this.salario = this.salario+1000;
    }

    @Override
    public void fazHoraExtra() {
        if(!this.horaExtra){ 
            this.jornadaDeTrabalho = this.jornadaDeTrabalho+10;
            this.horaExtra = true;
        }
        else{
            this.horaExtra = false;
            this.jornadaDeTrabalho = this.jornadaDeTrabalho-10;
        }
    }

    @Override
    public void adicionalNoturno() {
        if(!this.adicionalNoturno){
            this.adicionalNoturno = true;
            this.salario = this.salario + 500;
        }
        else{
            this.adicionalNoturno = false;
            this.salario = this.salario - 500;
        }
    }
}

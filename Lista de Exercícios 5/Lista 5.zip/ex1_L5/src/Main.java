
public class Main {


    public static void main(String[] args) {
        TelaPrincipal janela = new TelaPrincipal();
        
        janela.setLocationRelativeTo(null);
        
        janela.setVisible(true);
    }
}

package exercicio04;

import java.awt.BorderLayout;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class TelaGerenciamento extends javax.swing.JPanel {
    ArrayList <Pessoa> candidatos, contratados;  //Uma lista para os candidatos e outra para os contratados.
    DefaultListModel<String> model1, model2;  //Objetos de modelo para gerenciar o conteudo dos JLists.
    
    //Recebe duas informações por parâmetro, a lista de candidatos e a lista de contratados.
    //Quando o fluxo for tela de cadastro (tela A) -> tela de gerenciamento (tela B), recebe a lista e null.
    //Quando o fluxo for da tela de visualização (tela C) -> tela de gerenciamento (tela B), recebe a lista de candidatos e a lista de contratados.
    public TelaGerenciamento(ArrayList<Pessoa> listaCandidatos, ArrayList<Pessoa> listaContratados) {
        initComponents();
        
        //Inicializa as listas;
        if(listaCandidatos != null){
            this.candidatos = listaCandidatos;
        }
        else{
            this.candidatos = new ArrayList();
        }
        
        if(listaContratados != null){
            this.contratados = listaContratados;
        }
        else{
            this.contratados = new ArrayList();
        }
        
        //Inicializa os modelos.
        this.model1 = new DefaultListModel();
        this.model2 = new DefaultListModel();
        
        //Preenche os JList.
        inicializaJLists();
    }
    
    //Método para preencher os JList com os conteúdos das listas.
    public void inicializaJLists(){
        if(this.candidatos != null){
            for(int i=0 ; i<this.candidatos.size(); i++){  //Percorre a lista de candidatos adicionando os elementos ao modelo.
                this.model1.addElement(this.candidatos.get(i).getNome());
            }   
        }
        
        if(this.contratados != null){
            for(int i=0 ; i<this.contratados.size(); i++){  //Percorre a lista de contratados adicionando os elementos ao modelo.
                this.model2.addElement(this.contratados.get(i).getNome());
            }
        }
        
        //Seta o modelo utilizado pelos JList para os modelos criados.
        this.jl_candidatos.setModel(this.model1);
        this.jl_contratados.setModel(this.model2);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jScrollPane35 = new javax.swing.JScrollPane();
        jl_candidatos = new javax.swing.JList<>();
        bt_add = new javax.swing.JButton();
        bt_remove = new javax.swing.JButton();
        bt_add_all = new javax.swing.JButton();
        bt_remove_all = new javax.swing.JButton();
        jScrollPane36 = new javax.swing.JScrollPane();
        jl_contratados = new javax.swing.JList<>();
        bt_cancelar = new javax.swing.JButton();
        bt_proximo = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(550, 450));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("Contratação de Funcionários");

        jLabel34.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel34.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel34.setText("Lista de Candidatos");

        jLabel35.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel35.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel35.setText("Contratados");

        jl_candidatos.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jScrollPane35.setViewportView(jl_candidatos);

        bt_add.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        bt_add.setText("Adicionar >>");
        bt_add.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bt_addMouseClicked(evt);
            }
        });

        bt_remove.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        bt_remove.setText("<< Remover");
        bt_remove.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bt_removeMouseClicked(evt);
            }
        });

        bt_add_all.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        bt_add_all.setText("<html><p style=\"text-align:center\">Adicionar<br>Todos</p></html>");
        bt_add_all.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        bt_add_all.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bt_add_allMouseClicked(evt);
            }
        });

        bt_remove_all.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        bt_remove_all.setText("<html><p style=\"text-align:center\">Remover<br>Todos</p></html>");
        bt_remove_all.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bt_remove_allMouseClicked(evt);
            }
        });

        jl_contratados.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jScrollPane36.setViewportView(jl_contratados);

        bt_cancelar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        bt_cancelar.setText("<< Voltar");
        bt_cancelar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bt_cancelarMouseClicked(evt);
            }
        });

        bt_proximo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        bt_proximo.setText("Próximo >>");
        bt_proximo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bt_proximoMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel34, javax.swing.GroupLayout.DEFAULT_SIZE, 166, Short.MAX_VALUE)
                    .addComponent(jScrollPane35, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 47, Short.MAX_VALUE)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bt_add_all, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bt_remove_all, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bt_remove, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bt_add, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane36, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jLabel35, javax.swing.GroupLayout.DEFAULT_SIZE, 166, Short.MAX_VALUE)))
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addComponent(bt_cancelar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(bt_proximo))
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel34)
                    .addComponent(jLabel35))
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(bt_add)
                        .addGap(18, 18, 18)
                        .addComponent(bt_remove)
                        .addGap(18, 18, 18)
                        .addComponent(bt_add_all, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(bt_remove_all, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(140, Short.MAX_VALUE))
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane36, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
                            .addComponent(jScrollPane35))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(bt_cancelar)
                            .addComponent(bt_proximo))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jPanel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

    //Clique no botão adicionar.
    private void bt_addMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bt_addMouseClicked
        String selecionado = this.jl_candidatos.getSelectedValue(); //Captura o nome selecionado no JList de candidatos.
        Pessoa c = null;

        if(selecionado != null){ //Verifica se algum elemento do JList realmente foi selecionado.
            for(int i=0; i<this.candidatos.size(); i++){  //Percorre a lista de candidatos procurando pelo nome selecionado.
                if(selecionado.equals(this.candidatos.get(i).getNome())){ //Ao encontrar, recupera o candidato da lista.
                    c = this.candidatos.get(i);
                }
            }

            this.candidatos.remove(c);   //Remove o candidato da lista.
            this.model1.removeElement(selecionado); //Remove o candidato do JList.

            this.contratados.add(c);  //Adiciona o candidato na lista de contratados.
            this.model2.addElement(selecionado);  //Adiciona o candidato no JList de contratados.
        }
        else{
            JOptionPane.showMessageDialog(null, "Selecione um candidato da lista!", "Erro!", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bt_addMouseClicked

    //Clique no botão remover.
    private void bt_removeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bt_removeMouseClicked
        String selecionado = this.jl_contratados.getSelectedValue();  //Captura o nome selecionado no JList de candidatos.
        Pessoa c = null;

        if(selecionado != null){  //Verifica se algum elemento do JList realmente foi selecionado.
            for(int i=0; i<this.contratados.size(); i++){  //Percorre a lista de contratados procurando pelo nome selecionado.
                if(selecionado.equals(this.contratados.get(i).getNome())){  //Ao encontrar, recupera o contratado da lista.
                    c = this.contratados.get(i);
                }
            }

            this.contratados.remove(c);  //Remove o contratado da lista.
            this.model2.removeElement(selecionado);  //Remove o contratado do JList.

            this.candidatos.add(c);   //Adiciona o contratado na lista de candidatos.
            this.model1.addElement(selecionado);  //Adiciona o contratado no JList de candidatos.
        }
        else{
            JOptionPane.showMessageDialog(null, "Selecione um contratado da lista!", "Erro!", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bt_removeMouseClicked

    //Clique no botão adicionar todos.
    private void bt_add_allMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bt_add_allMouseClicked
        for(int i=0 ; i<this.candidatos.size(); i++){ //Percorre a lista de candidatos adicionando todos os candidatos na lista de contratados e no JList contratados.
            this.contratados.add(this.candidatos.get(i));
            this.model2.addElement(this.candidatos.get(i).getNome());
        }

        //Remove todos os elementos da lista de candidatos e do JList candidatos.
        this.model1.removeAllElements();
        this.candidatos.removeAll(this.candidatos);
    }//GEN-LAST:event_bt_add_allMouseClicked

    //Clique no botão cancelar.
    private void bt_cancelarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bt_cancelarMouseClicked
        Janela.telaA = new TelaCadastro();  //Inicializa o painel da tela de cadastro.
        JFrame janela = (JFrame)SwingUtilities.getWindowAncestor(this);  //Captura a referência ao frame.
        janela.getContentPane().remove(Janela.telaB);  //Remove o painel da tela de gerenciamento do frame.
        janela.add(Janela.telaA, BorderLayout.CENTER);  //Adiciona o painel de cadastro ao frame.
        janela.pack();  //Redimensiona o frame.
    }//GEN-LAST:event_bt_cancelarMouseClicked

    //Clique no botão próximo.
    private void bt_proximoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bt_proximoMouseClicked
        if(this.contratados.size() > 0){ //Verifica se existe algum candidato contratado.
            Janela.telaC = new TelaVisualizacao(this.candidatos, this.contratados); //Inicializa o painel da tela de visualização passando as listas de candidatos e contratados.
            JFrame janela = (JFrame)SwingUtilities.getWindowAncestor(this);  //Captura a referência ao frame.
            janela.getContentPane().remove(Janela.telaB); //Remove o painel de gerenciamento do frame.
            janela.add(Janela.telaC, BorderLayout.CENTER);   //Adiciona o painel de visualização ao frame.
            janela.pack(); //Redimensiona o frame.
        }
        else{  //Se não existir, mostra a janela de erro.
            JOptionPane.showMessageDialog(null, "Adicione algum candidato à lista de contratados antes de continuar!", "Erro!", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bt_proximoMouseClicked

    //Clique no botão remover todos.
    private void bt_remove_allMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bt_remove_allMouseClicked
       for(int i=0 ; i<this.contratados.size(); i++){   //Percorre a lista de contratados adicionando todos os contratados na lista de candidatos e no JList candidatos.
            this.candidatos.add(this.contratados.get(i));
            this.model1.addElement(this.contratados.get(i).getNome());
        }

       //Remove todos os elementos da lista de contratados e do JList contratados.
        this.model2.removeAllElements();
        this.contratados.removeAll(this.contratados);
    }//GEN-LAST:event_bt_remove_allMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt_add;
    private javax.swing.JButton bt_add_all;
    private javax.swing.JButton bt_cancelar;
    private javax.swing.JButton bt_proximo;
    private javax.swing.JButton bt_remove;
    private javax.swing.JButton bt_remove_all;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JScrollPane jScrollPane35;
    private javax.swing.JScrollPane jScrollPane36;
    private javax.swing.JList<String> jl_candidatos;
    private javax.swing.JList<String> jl_contratados;
    // End of variables declaration//GEN-END:variables
   
}

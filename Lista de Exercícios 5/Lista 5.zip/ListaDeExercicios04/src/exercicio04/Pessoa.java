package exercicio04;

public abstract class Pessoa {
    private String nome, formacao, areaDeInteresse; //Atributos.

    //Construtor.
    public Pessoa(String nome, String formacao, String areaDeInteresse){
        this.nome = nome;
        this.formacao = formacao;
        this.areaDeInteresse = areaDeInteresse;
    }
    
    //Getters e setters.
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getFormacao() {
        return formacao;
    }

    public void setFormacao(String formacao) {
        this.formacao = formacao;
    }

    public String getAreaDeInteresse() {
        return areaDeInteresse;
    }

    public void setAreaDeInteresse(String areaDeInteresse) {
        this.areaDeInteresse = areaDeInteresse;
    }
}

package exercicio04;

import java.awt.BorderLayout;

public class Janela extends javax.swing.JFrame {
    static TelaCadastro telaA;  //Objeto do painel tela de cadastro.
    static TelaGerenciamento telaB;  //Objeto do painel tela de gerenciamento.
    static TelaVisualizacao telaC;  //Objeto do painel tela de visualização.
    static TelaOpcoes telaD;
    public Janela() {       
        initComponents();
        
        telaA = new TelaCadastro(); //Inicializa o painel da tela inicial (cadastro).
        
        this.setLayout(new BorderLayout());  //Define o layout do frame como borderlayout.
        this.add(telaA, BorderLayout.CENTER); ////Adiciona o painel ao frame, na posição central.
        this.pack(); //Redimensiona o frame para ficar de acordo com o conteúdo do painel.
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setSize(new java.awt.Dimension(400, 300));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 405, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 352, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
    
}

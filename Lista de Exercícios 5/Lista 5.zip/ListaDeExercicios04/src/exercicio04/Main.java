package exercicio04;

public class Main {
    public static void main(String[] args) {
        Janela j = new Janela();        //Cria o frame
        j.setLocationRelativeTo(null);  //Posiciona no meio da tela.
        j.setVisible(true);             //Mostra o frame.
    }
}

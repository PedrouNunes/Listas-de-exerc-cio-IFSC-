
package exercicio04;


public class Candidato extends Pessoa{

    public Candidato(String nome, String formacao, String areaDeInteresse) {
        super(nome, formacao, areaDeInteresse);
    }

 
}

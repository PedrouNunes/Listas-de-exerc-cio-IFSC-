
package exercicio04;

public class Funcionario extends Pessoa implements Acoes{
    private double salario;
    private int jornadaDeTrabalho;
    private boolean hrExtra;
    private boolean adicionalNoturno;

    public Funcionario(double salario, int jornadaDeTrabalho, boolean hrExtra, boolean adicionalNoturno, String nome, String formacao, String areaDeInteresse) {
        super(nome, formacao, areaDeInteresse);
        this.salario = salario;
        this.jornadaDeTrabalho = jornadaDeTrabalho;
        this.hrExtra = hrExtra;
        this.adicionalNoturno = adicionalNoturno;
    }
    
    @Override
    public void reducaoSalarial() {
        this.salario -= 1000;
    }

    @Override
    public void aumentoSalarial() {
        this.salario += 1000;
    }

    @Override
    public void adicionalNoturno() {
        
    }

    @Override
    public void fazHoraExtra() {
        this.jornadaDeTrabalho += 200;
        this.jornadaDeTrabalho -= 200;
    }
    
    
}

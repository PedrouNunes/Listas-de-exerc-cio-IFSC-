
package exercicio03;


public class Comum extends Cliente{

    public Comum(String nome, int idade, String telefone, String sexo, String estado_civil) {
        super(nome, idade, telefone, sexo, estado_civil);
    }

    @Override
    public void imprimir() {
       System.out.println("Nome: " + super.nome);
        System.out.println("Idade: " + super.idade);
        System.out.println("Telefone: " + super.telefone);
        System.out.println("Sexo: " + super.sexo);
        System.out.println("Estado Civil: " + super.estado_civil + "\n");
    }
    
}

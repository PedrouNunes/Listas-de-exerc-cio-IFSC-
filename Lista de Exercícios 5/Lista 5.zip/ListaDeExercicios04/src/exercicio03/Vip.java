
package exercicio03;

public class Vip extends Cliente implements TratamentoVip{
private double desconto;

    public Vip(double desconto, String nome, int idade, String telefone, String sexo, String estado_civil) {
        super(nome, idade, telefone, sexo, estado_civil);
        this.desconto = desconto;
    }
   

    @Override
    public void enviarMsg() {
         System.out.println("Olá " + super.nome + ". Venha conferir nossas promoções. Uma oferta especial\n" +
"te aguarda. Na compra de qualquer produto você terá "+ desconto + "% de\n" +
"desconto"); 
    }

    @Override
    public void imprimir() {
       System.out.println("Nome: " + this.nome);
        System.out.println("Idade: " + this.idade);
        System.out.println("Telefone: " + this.telefone);
        System.out.println("Sexo: " + this.sexo);
        System.out.println("Estado Civil: " + this.estado_civil + "\n");
    }
    
}

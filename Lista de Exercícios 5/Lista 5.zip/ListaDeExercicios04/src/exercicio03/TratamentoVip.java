
package exercicio03;


public interface TratamentoVip {
    public void enviarMsg();
}

package exercicio03;

import java.awt.BorderLayout;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;


public class TelaVisualizar extends javax.swing.JPanel {
    ArrayList<Cliente> lista_clientes;  //Lista de clientes.
    
    public TelaVisualizar(ArrayList<Cliente> lista) {  //Recebe a lista de clientes cadastrados pelo construtor.
        initComponents();
        
        lista_clientes = lista; //Inicializa o arraylist com o valor da lista de clientes recebidos.
        
        for(int i=0; i<lista_clientes.size(); i++){
            cb_clientes.addItem(lista_clientes.get(i).getNome());  //Adiciona o nome dos clientes no combobox.
        }
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        cb_clientes = new javax.swing.JComboBox<>();
        bt_imprimir = new javax.swing.JButton();
        bt_remover = new javax.swing.JButton();
        btEnviarMensagem = new javax.swing.JButton();

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel1.setText("Clientes");

        cb_clientes.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        bt_imprimir.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        bt_imprimir.setText("Imprimir");
        bt_imprimir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bt_imprimirMouseClicked(evt);
            }
        });

        bt_remover.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        bt_remover.setText("Remover");
        bt_remover.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bt_removerMouseClicked(evt);
            }
        });

        btEnviarMensagem.setText("Enviar Mensagem");
        btEnviarMensagem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btEnviarMensagemMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(bt_imprimir)
                                .addGap(18, 18, 18)
                                .addComponent(bt_remover)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(cb_clientes, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(71, 71, 71)
                                .addComponent(jLabel1))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(33, 33, 33)
                                .addComponent(btEnviarMensagem)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(cb_clientes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bt_imprimir)
                    .addComponent(bt_remover))
                .addGap(18, 18, 18)
                .addComponent(btEnviarMensagem)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    //Clique no botão imprimir.
    private void bt_imprimirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bt_imprimirMouseClicked
        String nome = cb_clientes.getSelectedItem().toString();  //Captura o nome selecionado no combobox.

        for(int i=0; i<lista_clientes.size(); i++){  //Percorre a lista de clientes buscando pelo cliente com o nome selecionado no combobox.
            if(lista_clientes.get(i).getNome().equals(nome)){  //Quando encontra o cliente, mostra a tela de imprimir.
                Janela.telaC = new TelaImprimir(lista_clientes.get(i), lista_clientes);   //Inicializa o painel da tela de imprimir passando o cliente selecionado.
                JFrame janela = (JFrame) SwingUtilities.getWindowAncestor(this); //Captura a referência ao frame.
                janela.getContentPane().remove(Janela.telaB);  //Remove o painel de visualização do frame.
                janela.add(Janela.telaC, BorderLayout.CENTER);  //Adiciona o painel de impressão ao frame.
                janela.pack();  //Redimensiona o frame.
            }
        }
    }//GEN-LAST:event_bt_imprimirMouseClicked

    
    //Clique no botão remover.
    private void bt_removerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bt_removerMouseClicked
        switch(JOptionPane.showConfirmDialog(this, "Tem certeza disso?")){
            case 0: //sim
            String nome = cb_clientes.getSelectedItem().toString(); //Captura o nome selecionado no combobox.

            for(int i=0; i<lista_clientes.size(); i++){  //Percorre a lista de clientes buscando pelo cliente com o nome selecionado no combobox.
                if(lista_clientes.get(i).getNome().equals(nome)){  //Quando encontra o cliente, remove da lista e do combobox.
                    lista_clientes.remove(i);
                    cb_clientes.removeItemAt(i);

                    if(lista_clientes.size() == 0){  //Verifica o tamanho da lista de clientes, se todos foram removidos, mostra a tela de cadastro.
                        Janela.telaA = new TelaCadastro();   //Inicializa o painel da tela de cadastro.
                        JFrame janela = (JFrame) SwingUtilities.getWindowAncestor(this); //Captura a referência ao frame.
                        janela.getContentPane().remove(Janela.telaB);  //Remove o painel de visualização do frame.
                        janela.add(Janela.telaA, BorderLayout.CENTER);  //Adiciona o painel de cadastro ao frame.
                        janela.pack();  //Redimensiona o frame.
                    }
                }
            }
            break;
            case 1:
            break;
            case 2:
            break;
        }
    }//GEN-LAST:event_bt_removerMouseClicked

    private void btEnviarMensagemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btEnviarMensagemMouseClicked
        for (int i = 0; i < lista_clientes.size(); i++) {
            if (lista_clientes.get(i) instanceof Vip) {
                Vip vip = (Vip)lista_clientes.get(i);
                vip.enviarMsg();
            }
        }
    }//GEN-LAST:event_btEnviarMensagemMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btEnviarMensagem;
    private javax.swing.JButton bt_imprimir;
    private javax.swing.JButton bt_remover;
    private javax.swing.JComboBox<String> cb_clientes;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}

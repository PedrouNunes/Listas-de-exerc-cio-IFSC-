package exercicio02;

import java.awt.BorderLayout;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class TelaCadastro extends javax.swing.JPanel {
    ArrayList<Cliente> lista_clientes;   //Arraylist para armazenar os clientes cadastrados.
  
    
    public TelaCadastro() {
        initComponents();
        lista_clientes = new ArrayList();
         //Inicializa o Arraylist.
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        tf_idade = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        tf_telefone = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        rb_masculino = new javax.swing.JRadioButton();
        rb_feminino = new javax.swing.JRadioButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        cb_estado_civil = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        bt_cadastrar = new javax.swing.JButton();
        tf_nome = new javax.swing.JTextField();
        bt_visualizar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        rbVip = new javax.swing.JRadioButton();
        rbComum = new javax.swing.JRadioButton();

        tf_idade.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tf_idade.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tf_idadeKeyTyped(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("Telefone:");

        tf_telefone.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tf_telefone.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tf_telefoneKeyTyped(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("Sexo:");

        buttonGroup1.add(rb_masculino);
        rb_masculino.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        rb_masculino.setText("Masculino");

        buttonGroup1.add(rb_feminino);
        rb_feminino.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        rb_feminino.setText("Feminino");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("Estado Civil:");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel1.setText("Cadastro de Clientes");

        cb_estado_civil.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        cb_estado_civil.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Solteiro", "Casado", "Divorciado", "Viúvo" }));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Nome:");

        bt_cadastrar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        bt_cadastrar.setText("Cadastrar");
        bt_cadastrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bt_cadastrarMouseClicked(evt);
            }
        });

        tf_nome.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        bt_visualizar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        bt_visualizar.setText("Visualizar");
        bt_visualizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bt_visualizarMouseClicked(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Idade:");

        jLabel7.setText("Tipo:");

        buttonGroup2.add(rbVip);
        rbVip.setText("Vip");

        buttonGroup2.add(rbComum);
        rbComum.setText("Comum");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(tf_nome, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(tf_idade, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(tf_telefone, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(rb_masculino)
                        .addGap(28, 28, 28)
                        .addComponent(rb_feminino))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(114, 114, 114)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addComponent(cb_estado_civil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rbVip)
                        .addGap(18, 18, 18)
                        .addComponent(rbComum))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(71, 71, 71)
                        .addComponent(bt_cadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bt_visualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(tf_nome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(tf_idade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(tf_telefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(rb_masculino)
                        .addComponent(rb_feminino)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(cb_estado_civil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(rbVip)
                    .addComponent(rbComum))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bt_cadastrar)
                    .addComponent(bt_visualizar))
                .addContainerGap(15, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    //Método para permitir que o usuário digite somente números no campo idade.
    private void tf_idadeKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tf_idadeKeyTyped
        char key = evt.getKeyChar();  //Recupera o caractere digitado.
        if(!(Character.isDigit(key))){  //Se for diferente de um digito, apaga.
            evt.consume();
        }
    }//GEN-LAST:event_tf_idadeKeyTyped

    //Método para permitir que o usuário digite somente números no campo telefone.
    private void tf_telefoneKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tf_telefoneKeyTyped
        char key = evt.getKeyChar();  //Recupera o caractere digitado.
        if(!(Character.isDigit(key))){  //Se for diferente de um digito, apaga.
            evt.consume();
        }
    }//GEN-LAST:event_tf_telefoneKeyTyped

    //Clique no botão cadastrar.
    private void bt_cadastrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bt_cadastrarMouseClicked
        String nome="", telefone="", sexo="", estado_civil="";
        int idade = 0;

        nome = tf_nome.getText();  //Recupera as informações preenchidas nos campos do formulário.
        if(!tf_idade.getText().equals("")){
            idade = Integer.parseInt(tf_idade.getText());
        }

        telefone = tf_telefone.getText();

        if(rb_masculino.isSelected()){  //Verifica qual botão está selecionado.
            sexo = "masculino";
        }
        else if(rb_feminino.isSelected()){
            sexo = "feminino";
        }

        estado_civil = cb_estado_civil.getSelectedItem().toString();

        //Verifica se todos os campos estão preenchidos.
        if(!nome.equals("") && idade != 0 && !telefone.equals("") && !sexo.equals("") && !estado_civil.equals("")){
            if(rbVip.isSelected()){
            Cliente c = new Vip(10, nome, idade, telefone, sexo, estado_civil);  //Cria um objeto cliente com as informações do formulário.
            lista_clientes.add(c);  //Adiciona o objeto na lista.
            }else{
                if(rbComum.isSelected()){
                    Cliente c = new Comum(nome, idade, telefone, sexo, estado_civil);  //Cria um objeto cliente com as informações do formulário.
                    lista_clientes.add(c);  //Adiciona o objeto na lista.
                }
            }
            
            this.limparCampos();  //Limpa os campos do formulário.

            //Mostra a mensagem de sucesso.
            JOptionPane.showMessageDialog(null, "Cliente cadastrado com sucesso!", "Mensagem", JOptionPane.INFORMATION_MESSAGE);
        }
        else{
            //Caso algum campo não tenha sido preenchido, mostra a mensagem de erro.
            JOptionPane.showMessageDialog(null, "Você deve preencher todos os campos!", "Erro!", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_bt_cadastrarMouseClicked

    //Clique no botão visualizar.
    private void bt_visualizarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bt_visualizarMouseClicked
        if(lista_clientes.size() > 0){  //Verifica se existe algum cliente cadastrado.
            Janela.telaB = new TelaVisualizar(this.lista_clientes);  //Inicializa o painel da tela de visualizar passando a lista de clientes cadastrados.
            JFrame janela = (JFrame) SwingUtilities.getWindowAncestor(this);  //Captura a referência ao frame.
            janela.getContentPane().remove(Janela.telaA);  //Remove o painel de cadastro do frame.
            janela.add(Janela.telaB, BorderLayout.CENTER); //Adiciona o painel de visualização ao frame.
            janela.pack(); //Redimensiona o frame.
        }
        else{  //Se não houver clientes cadastrados, mostra a mensagem de erro.
            JOptionPane.showMessageDialog(null, "Não existe nenhum cliente cadastrado!", "Erro!", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bt_visualizarMouseClicked

    //Método para limpar os campos do formulário.
    private void limparCampos(){
        tf_nome.setText("");
        tf_idade.setText("");
        tf_telefone.setText("");
        buttonGroup1.clearSelection();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt_cadastrar;
    private javax.swing.JButton bt_visualizar;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JComboBox<String> cb_estado_civil;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JRadioButton rbComum;
    private javax.swing.JRadioButton rbVip;
    private javax.swing.JRadioButton rb_feminino;
    private javax.swing.JRadioButton rb_masculino;
    private javax.swing.JTextField tf_idade;
    private javax.swing.JTextField tf_nome;
    private javax.swing.JTextField tf_telefone;
    // End of variables declaration//GEN-END:variables
}

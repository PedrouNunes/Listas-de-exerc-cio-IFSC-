
package exercicio02;

public interface TratamentoVip {
    public void enviarMsg();
}

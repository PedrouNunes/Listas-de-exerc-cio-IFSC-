
package exercicio01;

public interface TratamentoVip {
    public abstract void enviarMag();
}


package exercicio01;

public class VIP extends Cliente implements TratamentoVip{

    public VIP(double desconto, String nome, int idade, String telefone, String sexo, String estado_civil) {
        super(nome, idade, telefone, sexo, estado_civil);
        this.desconto = desconto;
    }
 
    private double desconto;

    @Override
    public void enviarMag() {
        
    }

    @Override
    public String toString() {
        return "VIP{" + "desconto=" + desconto + '}';
    }
}
